<?php
if(isset($_GET['id'])){
$id=$_GET['id'];
$con=mysqli_connect("localhost","root","","class");
	$query=mysqli_query($con,"delete from students where id='$id' ");
	if($query){
		header("Location: select.php");
	}
	else{
			header("location:logout.php");
		}
	}
	?>