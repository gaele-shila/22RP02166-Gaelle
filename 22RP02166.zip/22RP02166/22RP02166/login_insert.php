<?php
include('connection.php');  
if(isset($_POST['send'])){
	
	$username=$_POST['username'];
	$password=$_POST['password'];
	$email=$_POST['email'];
	
	$query=mysqli_query($con,"insert into users(username,password,email)values('$username','$password','$email')");
	if($query==true)
	{
		echo "inserted";
		header("Location: loginform.php");
	}
	else {
		echo "data is not inserted";
	}
}
?>